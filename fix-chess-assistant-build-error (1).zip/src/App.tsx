const fixes = [
  {
    title: 'ECONNRESET при сборке',
    text: 'Раньше packager заново качал Electron с GitHub, и соединение обрывалось. Теперь build.js берёт Electron, который уже скачал npm install (node_modules\\electron\\dist), и собирает программу без интернета. Если Electron не найден, включается запасной вариант: 4 попытки и зеркало npmmirror.',
  },
  {
    title: "Ошибки 'ho', 'рнет', 'stant.exe...'",
    text: 'Батники теперь только в ASCII, с переводами строк CRLF и без блоков со скобками. Русский текст печатает Node.js, а не cmd.exe.',
  },
  {
    title: 'Не было файла движка',
    text: 'В репозитории отсутствовал stockfish-19-lite-single.wasm (1,8 МБ). Без него программа собралась бы, но подсказки не работали бы. Я добавил его в архив.',
  },
  {
    title: 'Повторы при обрыве сети',
    text: 'Добавлен .npmrc с повторами и таймаутами, а build.bat при сбое npm install сам пробует ещё раз через зеркало.',
  },
];

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="mx-auto max-w-3xl px-6 py-14">
        <div className="mb-8 flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500 text-3xl text-slate-950">
            ♞
          </div>
          <div>
            <h1 className="text-2xl font-bold">Chess Assistant: исправленный проект</h1>
            <p className="text-sm text-slate-400">Полный архив с батниками, кодом и движком Stockfish</p>
          </div>
        </div>

        <a
          href="./chess-assistant.zip"
          download="chess-assistant.zip"
          className="mb-8 flex items-center justify-between gap-4 rounded-2xl bg-emerald-500 px-6 py-5 text-slate-950 shadow-lg shadow-emerald-500/20 transition hover:bg-emerald-400"
        >
          <div>
            <div className="text-lg font-bold">⬇ Скачать chess-assistant.zip</div>
            <div className="text-sm opacity-80">1,2 МБ · всё внутри, ничего докачивать не нужно</div>
          </div>
          <span className="text-3xl">📦</span>
        </a>

        <section className="mb-6 rounded-2xl border border-slate-700 bg-slate-900 p-5">
          <h2 className="mb-3 font-semibold">Как собрать .exe</h2>
          <ol className="list-decimal space-y-2 pl-5 text-sm text-slate-300">
            <li>
              Установите <b>Node.js LTS</b> с nodejs.org (если ещё не стоит).
            </li>
            <li>
              Распакуйте zip в простую папку, например <code className="rounded bg-slate-800 px-1">C:\ChessAssistant</code>.
              Лучше без кириллицы в пути.
            </li>
            <li>
              Дважды кликните <b>build.bat</b> и дождитесь слова <b>DONE!</b> (2-5 минут).
            </li>
          </ol>
        </section>

        <section className="mb-6 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-5">
          <h2 className="mb-2 font-semibold text-amber-300">📁 Где будет готовая программа</h2>
          <p className="mb-3 text-sm text-slate-300">
            Папка <b>dist</b> создаётся автоматически <b>рядом с build.bat</b>, внутри распакованной папки проекта.
            Окно с ней откроется само после сборки.
          </p>
          <pre className="overflow-x-auto rounded-xl bg-slate-950 p-4 text-xs leading-relaxed text-emerald-300">
{`C:\\ChessAssistant\\          <- куда вы распаковали
├─ build.bat
├─ main.js, src\\, ui\\, engine\\ ...
└─ dist\\
   └─ ChessAssistant-win32-x64\\
      └─ ChessAssistant.exe   <- ЗАПУСКАТЬ ЭТОТ ФАЙЛ`}
          </pre>
          <p className="mt-3 text-xs text-slate-400">
            Всю папку ChessAssistant-win32-x64 можно скопировать куда угодно, например на рабочий стол. Рядом с
            exe должны остаться остальные файлы.
          </p>
        </section>

        <section className="mb-6 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-5">
          <h2 className="mb-3 font-semibold text-emerald-300">Что исправлено</h2>
          <div className="space-y-3">
            {fixes.map((f) => (
              <div key={f.title}>
                <div className="text-sm font-semibold text-slate-100">✔ {f.title}</div>
                <p className="text-sm leading-relaxed text-slate-300">{f.text}</p>
              </div>
            ))}
          </div>
        </section>

        <p className="text-xs text-slate-500">
          Если что-то снова не получится, пришлите последние строки из окна build.bat. Если ошибка
          ECONNRESET повторяется, попробуйте включить или выключить VPN и запустить build.bat ещё раз.
        </p>
      </div>
    </div>
  );
}
