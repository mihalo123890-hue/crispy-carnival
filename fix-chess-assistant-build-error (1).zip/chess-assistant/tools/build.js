'use strict';
/**
 * Сборка Windows-приложения (EXE).
 * Результат: <папка проекта>\dist\ChessAssistant-win32-x64\ChessAssistant.exe
 *
 * Способ 1 (основной, БЕЗ скачивания из интернета):
 *   берём уже установленный Electron из node_modules\electron\dist
 *   (его скачал "npm install"), копируем рядом наши файлы -> готовая программа.
 * Способ 2 (запасной): @electron/packager с повторными попытками и зеркалом.
 */
const path = require('path');
const fs = require('fs');

const root = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const OUT_NAME = 'ChessAssistant-win32-x64';
const outDir = path.join(root, 'dist', OUT_NAME);

const APP_FILES = ['package.json', 'main.js', 'preload.js', 'src', 'ui', 'engine'];

function rmrf(p) {
  fs.rmSync(p, { recursive: true, force: true, maxRetries: 5, retryDelay: 300 });
}

/** Все production-зависимости (рекурсивно) -> набор имён пакетов. */
function collectDeps(names, seen = new Set()) {
  for (const name of names) {
    if (seen.has(name)) continue;
    const pj = path.join(root, 'node_modules', name, 'package.json');
    if (!fs.existsSync(pj)) {
      throw new Error('Не найден пакет "' + name + '" в node_modules. Выполните npm install.');
    }
    seen.add(name);
    const deps = Object.keys(JSON.parse(fs.readFileSync(pj, 'utf8')).dependencies || {});
    collectDeps(deps, seen);
  }
  return seen;
}

function findElectronDist() {
  const dist = path.join(root, 'node_modules', 'electron', 'dist');
  if (fs.existsSync(path.join(dist, 'electron.exe'))) return dist;
  return null;
}

/** Способ 1: сборка из локального Electron, без интернета. */
function buildLocal(electronDist) {
  console.log('Способ 1: использую уже скачанный Electron:');
  console.log('  ' + electronDist);

  rmrf(outDir);
  fs.mkdirSync(path.dirname(outDir), { recursive: true });
  fs.cpSync(electronDist, outDir, { recursive: true });

  // electron.exe -> ChessAssistant.exe
  fs.renameSync(path.join(outDir, 'electron.exe'), path.join(outDir, 'ChessAssistant.exe'));
  // стандартная заглушка Electron не нужна
  rmrf(path.join(outDir, 'resources', 'default_app.asar'));

  const appDir = path.join(outDir, 'resources', 'app');
  fs.mkdirSync(appDir, { recursive: true });

  for (const f of APP_FILES) {
    const src = path.join(root, f);
    if (!fs.existsSync(src)) {
      if (f === 'preload.js') continue;
      throw new Error('Не найден файл/папка проекта: ' + f);
    }
    fs.cpSync(src, path.join(appDir, f), { recursive: true });
  }

  const deps = collectDeps(Object.keys(pkg.dependencies || {}));
  for (const name of deps) {
    fs.cpSync(path.join(root, 'node_modules', name), path.join(appDir, 'node_modules', name), {
      recursive: true,
    });
  }
  return outDir;
}

/** Способ 2: @electron/packager (нужно скачивание Electron). */
async function buildPackager() {
  console.log('Способ 2: @electron/packager (потребуется интернет)...');
  const mod = require('@electron/packager');
  const packager = mod.packager || mod.default || mod;
  let lastErr;
  for (let attempt = 1; attempt <= 4; attempt++) {
    try {
      if (attempt === 3) {
        console.log('Переключаюсь на зеркало npmmirror.com ...');
        process.env.ELECTRON_MIRROR = 'https://npmmirror.com/mirrors/electron/';
      }
      const out = await packager({
        dir: root,
        name: 'ChessAssistant',
        executableName: 'ChessAssistant',
        platform: 'win32',
        arch: 'x64',
        out: path.join(root, 'dist'),
        overwrite: true,
        prune: true,
        asar: false, // движок Stockfish запускается как отдельный процесс из файлов
        ignore: [
          /^\/dist($|\/)/,
          /^\/test($|\/)/,
          /^\/tools($|\/)/,
          /^\/README\.md$/,
          /\.bat$/i,
          /^\/\.git/,
        ],
      });
      return out[0];
    } catch (e) {
      lastErr = e;
      console.log('Попытка ' + attempt + ' не удалась: ' + (e && e.message ? e.message : e));
      await new Promise((r) => setTimeout(r, 3000 * attempt));
    }
  }
  throw lastErr;
}

(async () => {
  console.log('Сборка ChessAssistant.exe ...');
  let result;
  const dist = findElectronDist();
  if (dist) {
    try {
      result = buildLocal(dist);
    } catch (e) {
      console.log('Способ 1 не сработал: ' + (e && e.message ? e.message : e));
    }
  } else {
    console.log('Локальный Electron (electron.exe) не найден в node_modules.');
  }
  if (!result) result = await buildPackager();

  const exe = path.join(result, 'ChessAssistant.exe');
  if (!fs.existsSync(exe)) throw new Error('ChessAssistant.exe не найден в ' + result);
  if (!fs.existsSync(path.join(result, 'resources', 'app', 'engine', 'stockfish-19-lite-single.wasm'))) {
    console.log('ПРЕДУПРЕЖДЕНИЕ: нет engine\\stockfish-19-lite-single.wasm - движок не запустится!');
  }

  console.log('\nГОТОВО! Программа находится здесь:');
  console.log('  ' + exe);
  console.log('\nПапку ' + OUT_NAME + ' целиком можно перенести куда угодно.');
})().catch((e) => {
  console.error('\nОШИБКА СБОРКИ:', e && e.stack ? e.stack : e);
  process.exit(1);
});
