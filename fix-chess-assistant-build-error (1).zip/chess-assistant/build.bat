@echo off
rem ==========================================================
rem  Chess Assistant - build EXE for Windows
rem  NOTE: this file must be ASCII-only with CRLF line endings.
rem  Do NOT put Cyrillic text in here - cmd.exe breaks on it.
rem  (Russian messages are printed by tools\build.js instead.)
rem ==========================================================
setlocal EnableExtensions
cd /d "%~dp0"

echo ==================================================
echo   Chess Assistant - building EXE for Windows
echo ==================================================
echo.
echo Project folder: %~dp0
echo Result will be: %~dp0dist\ChessAssistant-win32-x64\ChessAssistant.exe
echo.

where node >nul 2>nul
if errorlevel 1 goto :no_node

echo [1/3] Installing dependencies - internet required, first run takes 2-5 min...
call npm install
if not errorlevel 1 goto :install_ok

echo.
echo [WARNING] npm install failed - probably network error. Retrying via mirror...
set "ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/"
call npm install
if errorlevel 1 goto :fail_install

:install_ok
echo.
echo [2/3] Running self-test...
call npm test
if errorlevel 1 echo [WARNING] Self-test failed, continuing build anyway.

echo.
echo [3/3] Building ChessAssistant.exe...
call npm run pack
if errorlevel 1 goto :fail_pack

echo.
echo ==================================================
echo   DONE!
echo   Program: %~dp0dist\ChessAssistant-win32-x64\ChessAssistant.exe
echo ==================================================
start "" explorer "%~dp0dist\ChessAssistant-win32-x64"
pause
endlocal
exit /b 0

:no_node
echo [ERROR] Node.js not found.
echo Install Node.js LTS from https://nodejs.org and run build.bat again.
echo.
pause
exit /b 1

:fail_install
echo [ERROR] npm install failed twice. Check your internet / VPN / antivirus and try again.
pause
exit /b 1

:fail_pack
echo [ERROR] Build failed. See messages above.
pause
exit /b 1
