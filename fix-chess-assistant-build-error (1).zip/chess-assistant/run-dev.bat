@echo off
rem ASCII-only file with CRLF line endings. Do not add Cyrillic text here.
setlocal EnableExtensions
cd /d "%~dp0"
if not exist node_modules call npm install
call npm start
endlocal
